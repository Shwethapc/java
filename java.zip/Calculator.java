 import java.util.Scanner;
 class Calculator{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter ur choice");
        int ch=sc.nextInt();
      System.out.println("Enter first number");
      int n1 = sc.nextInt();
      System.out.println("Enter second number");
      int  n2=sc.nextInt();
      switch(ch)
      {
        case 1:
            int n4 =n1 + n2;
            System.out.println("Addition:" + n4);
            break;
        case 2:
            int n3 = n1 - n2;
            System.out.println("Subtraction:" +  n3);
            break;
        case 3:
            System.out.println("Multiplication:" + n1 * n2);
            break;
        case 4:
            System.out.println("Division: " + n1 / n2);
            break;
        default:
            System.out.println("error:enter valid choice");

            
      }

    }
}