//Encapsulation binding data into a single unit
class Person{
    //create private variables
   private  String name;
    private int Age;


//getter method for name
public String getName(){
    return name;
}
//setter method for name
public void setName(String name){
    //we can add validation here if needed
    if(name != null &&  name.isEmpty()){
        System.out.println("Invalid Name:" + name);

    }
    else{
        this.name = name;

    }
}
//getter method for age
public int getAge(){
    return Age;

}
// setter method for age
public void  setAge(int age){
    if(Age > 0){
        System.out.println("Invalid age:" + age);

    }
    else{
        this.Age= age;
    }
}

}
public class Encaps{
    public static void main(String[] args) {
        Person person= new Person();
        //set the nameand age setters method
        person.setName("Shwetha");
        person.setAge(21);

        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
    

        //this will be print an error message
    }
}


