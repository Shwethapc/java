class Ifelse
{
    public static   void main(String[] args)
    {
        int num=5;
        if(num%2==0)
        {
            System.out.println("The number is even");
        }
        else
        {
            System.out.println("The number is odd");
        }

    }
    

}