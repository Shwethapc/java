//Single Ineritance

class Bird{
    void fly(){
        System.out.println("Bird can fly");
    }
}
class Parrot extends Bird{
    void color(){
        System.out.println("i am green");
    }

}

class cow extends Parrot{
    void whatcoloriam(){
        System.out.println("I am Black");
    }
}

public class Inheritance{

    
    public static void main(String[] args) {
        //object for parrot
        Parrot p=new Parrot();
        p.fly();
        p.color();

        //object for cow
        cow c=new cow();
        c.fly();
        c.whatcoloriam();

    }
}