//It belongs to instaance class Instance method
public class Instancemethod{
    //public void display(String name){
      //  System.out.println("Name:" + name);
  //  }
  public static int square(int number){
    return  number * number;
  }
    public static void main(String[] args) {
      //Instancemethod instance = new Instancemethod();
      //instance.display("Shwetha");
      int result = Instancemethod.square(5);
      System.out.println("Square of 5 is :"+ result);
    }
}