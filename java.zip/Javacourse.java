class Shwetha
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to java first class..");
    }
}