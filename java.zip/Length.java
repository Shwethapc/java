import java.util.Scanner;

class Length {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character");
        String var = sc.next();
        int length = var.length();


        System.out.println("The length of a character is :" + length );
    }
}