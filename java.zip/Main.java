//one class inherit from another class
 class Bird{
    void fly(){
        System.out.println("Bird can fly");
    }
}
    class Parot extends Bird{
        void color(){
            System.out.println("i am green");
        }

    }

public class Main{

    
    public static void main(String[] args) {
        Parot p=new Parot();
        p.color();
        p.fly();
    }
}
