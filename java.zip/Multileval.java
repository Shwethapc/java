class Bird{
    void fly(){
        System.out.println("Bird can fly");
    }
}
    class Parrot extends Bird{
        void color(){
            System.out.println("i am green");
        }

    }

    //Inheriting class parrot
    /*class singleparrot extends Parrot{
        void sing(){
            System.out.println("i can sing");
        }
    }
        

    class cow extends Bird{
        void whatcoloriam(){
            System.out.println("I am black");
        }
    }*/

public class Multileval{

    
    public static void main(String[] args) {
        Parrot p=new Parrot();
        cow s=new cow();
        s.whatcoloriam();
        p.color();
        p.fly();
        s.fly();
    }
}
/*Multiple inheritance 2 parent class and single derived class
class A{
void testMethod(){

}
}
class B{
void method(){

}
class C extends A,B
}*/

