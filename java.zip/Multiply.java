import java.util.Scanner;

class Multiply{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
      System.out.println("Enter the first number");
      double n1 = sc.nextInt();
      System.out.println("Enter the second number");
      double n2 = sc.nextInt();
      double  n3 =n1 * n2;
      System.out.println("Multiply :" + n3);
    }
}