import java.util.Scanner;
public class Palindrome
{
    public static void main(String[] args) {
        int n,sum =0, r= 0,rev ;
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a number");
        n = sc.nextInt();
        rev = n;
        while(n > 0){
            r = n % 10;
            sum =(sum * 10 )+ r;
            n = n / 10;

        }
        if(rev == sum){
        System.out.println("number is palindrome");

    }
    else{
        System.out.println("Number is not palindrome");
    }
}
}