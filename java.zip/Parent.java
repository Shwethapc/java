class Paren {
    public void  parent(){
        System.out.println("This is parent class");
    }
    
}
class Child extends  Paren{
    public void parent (){
    System.out.println("This is child class");
    }
}
public class Parent{
public static void main(String[] args){
    Paren myParent = new Paren();
    Paren myChild = new Child();

    myParent.parent();
    myChild.parent();

}
}

