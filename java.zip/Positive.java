import java.util.Scanner;
public class Positive{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the  number");
        int n1 = sc.nextInt();

        if(n1>=0){
            System.out.println("The number is positive");
        }
        else{
            System.out.println("The given number is negative");
        }

    }
}

