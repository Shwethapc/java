import java.util.Scanner;
public class Reverse
{
    public static void main(String[] args) {
        String reverse= " ";
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a string");
         String str = sc.nextLine();
         for( int i= str.length()- 1; i>=0; i--){
            reverse += str.charAt(i);
         }
         System.out.println("Reverse of a string is :" + reverse);
    }
}