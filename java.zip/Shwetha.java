class Shwetha{
    public static void main(String[] args)
    {
        System.out.println("Name:Shwetha p c");
        System.out.println("USN:1SV22CS104");
        System.out.println("Dept:CSE");
        System.out.println("Address:Madhugiri");
        System.out.println("College:Shridevi Engg clg");
    }
}