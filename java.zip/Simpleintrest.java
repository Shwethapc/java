import java.util.Scanner;
public class Simpleintrest
{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the principal amount");
        int P = sc.nextInt();
        System.out.println("Enter the time");
        int T= sc.nextInt();
        System.out.println("Enter the rate");
        int R = sc.nextInt();

        int SI= (P * T* R) /100;
        System.out.println("Simple intrest is :" + SI);

    }
}