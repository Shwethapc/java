
public class Switch{
    public static void main(String[] args) {
        int ch=2;
        switch(ch){
            case 1:
                 System.out.println("Monday:Ah i need cofee day...");
                 break;
            case 2:
                 System.out.println("Tuesday:Still not friday,but we are getting there!...");
                 break;
            case 3:
                 System.out.println("Wednesday:hump day,halfway to weekend..!");
            case 4:
                 System.out.println("Thursday:Almost friday ! hold the celebaration..for now..!");
                 break;
            case 5:
                 System.out.println("Friday:prty time..! or you know sleep time..args.!");
                 break;
            case 6:
                 System.out.println("Saturday:universal day..do Nothing day");
                 break;
            case 7:
                System.out.println("Sunday:panic day");
                break;
            default:System.out.println("error:You entered a day that doesn't exist...");
        }
    }
}