import java.util.Scanner;
public class Voting{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter Yur age ");
        int ch = sc.nextInt();
        if(ch>18){
            System.out.println("You are eligible to vote");
        }
            else{
                System.out.println("You are not eligible to vote try after some years");
            }
        }
    }