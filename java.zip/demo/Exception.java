

public class Exception {
    //Example for exception handling using try and catch blocks
    public static void main(String[] args) {
        try{
        //risky code that may handle cause an exception
        int a = 10 / 5; // this is Arithmetic exception
        System.out.println("Result :" + a);
        }
        catch(ArithmeticException e){
            //handle the exception
            System.out.println("Arithmrtic Exception:error Division by zero");
        }finally{
            //code that always executes
            System.out.println("this is finally block");
        }
        System.out.println("rest of the code");
    }

}